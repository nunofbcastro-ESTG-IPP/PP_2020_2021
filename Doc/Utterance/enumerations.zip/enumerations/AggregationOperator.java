package edu.ma02.core.enumerations;

/**
 * <h2>
 * Escola Superior de Tecnologia e Gestão (ESTG)<br>
 * Politécnico do Porto (PP)<br>
 * Licenciatura em Engenharia Informática (LEI)<br>
 * Licenciatura em Segurança Informática em Redes de Computadores (LSIRC)<br>
 * Paradigmas de Programação (PP)<br>
 * 2020 / 2021<br>
 * </h2>
 * <p>
 * Enumeration representing the operator used in {@link edu.ma02.core.interfaces.ICityStatistics statistics}
 * </p>
 *
 */
public enum AggregationOperator {
    /**
     * Average of a set of values
     */
    AVG, 
    /**
     * Count of a set of values
     */
    COUNT, 
    /**
     * Maximum value in a set of values
     */
    MAX, 
    /**
     * Maximum value in a set of values
     */
    MIN;
}
