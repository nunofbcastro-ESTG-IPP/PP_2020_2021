package edu.ma02.core.enumerations;
/**
 * <h2>
 * Escola Superior de Tecnologia e Gestão (ESTG)<br>
 * Politécnico do Porto (PP)<br>
 * Licenciatura em Engenharia Informática (LEI)<br>
 * Licenciatura em Segurança Informática em Redes de Computadores (LSIRC)<br>
 * Paradigmas de Programação (PP)<br>
 * 2020 / 2021<br>
 * </h2>
 * <p>
 * Enumeration representing the {@link Parameter parameter} based on {@link Unit unit}
 * </p>
 *
 */
public enum Parameter {

    /**
     * Dióxido de Azoto
     */
    NO2(Unit.UG_M3),

    /**
     * Ozono
     */
    O3(Unit.UG_M3),

    /**
     * Partículas com diâmetro inferior a 2.5 um
     */
    PM2_5(Unit.UG_M3),

    /**
     * Partículas com diâmetro inferior a 10 um
     */
    PM10(Unit.UG_M3),

    /**
     * Dióxido de Enxofre
     */
    SO2(Unit.UG_M3),

    /**
     * Benzeno
     */
    C6H6(Unit.UG_M3),

    /**
     * Monóxido de Carbono
     */
    CO(Unit.MG_M3),

    /**
     * Nível sonoro contínuo equivalente, em dB(A)
     */
    LAEQ(Unit.DB), 

    /**
     * Pressão Atmosférica
     */
    PA(Unit.MBAR), 

    /**
     * Temperatura
     */
    TEMP(Unit.DEGREE_CELSIUS), 

    /**
     * Radiação Ultravioleta
     */
    RU(Unit.UV), 

    /**
     * Direcção do Vento
     */
    VD(Unit.DEGREE), 

    /**
     * Intensidade do Vento
     */
    VI(Unit.KM_H), 

    /**
     * Humidade Relativa
     */
    HM(Unit.PERCENTAGE), 

    /**
     * Precipitação
     */
    PC(Unit.MM), 

    /**
     * Radiação Global
     */
    RG(Unit.W_M2);

    private final Unit unit;

    Parameter(Unit unit) {
        this.unit = unit;
    }

    /**
     * Getter for parameter unit
     * 
     * @return parameter unit
     */
    public Unit getUnit() {
        return unit;
    }

    /**
     * Returns the parameter textual representation
     * 
     * @param parameter the parameter
     * @return textual representation
     */
    public static String getParameterName(Parameter parameter) {
        switch (parameter) {
            case NO2:
                return "Dióxido de Azoto";
            case O3:
                return "Ozono";
            case PM2_5:
                return "Partículas com diâmetro inferior a 2.5 um";
            case PM10:
                return "Partículas com diâmetro inferior a 10 um";
            case SO2:
                return "Dióxido de Enxofre";
            case C6H6:
                return "Benzeno";
            case CO:
                return "Monóxido de Carbono";
            case LAEQ:
                return "Nível sonoro contínuo equivalente, em dB(A)";
            case PA:
                return "Pressão Atmosférica";
            case TEMP:
                return "Temperatura";
            case RU:
                return "Radiação Ultravioleta";
            case VD:
                return "Direcção do Vento";
            case VI:
                return "Intensidade do Vento";
            case HM:
                return "Humidade Relativa";
            case PC:
                return "Precipitação";
            case RG:
                return "Radiação Global";
            default:
                return null;
        }
    }
}
