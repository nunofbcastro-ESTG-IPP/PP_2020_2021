package edu.ma02.core.enumerations;

/**
 * <h2>
 * Escola Superior de Tecnologia e Gestão (ESTG)<br>
 * Politécnico do Porto (PP)<br>
 * Licenciatura em Engenharia Informática (LEI)<br>
 * Licenciatura em Segurança Informática em Redes de Computadores (LSIRC)<br>
 * Paradigmas de Programação (PP)<br>
 * 2020 / 2021<br>
 * </h2>
 * <p>
 * Enumeration representing the unit used in measures
 * </p>
 *
 */
public enum Unit {

    /**
     * Micrograms per Cubic Meter of Air
     */
    UG_M3,

    /**
     * Megagram per Cubic Meter
     */
    MG_M3,

    /**
     * Decibels 
     */
    DB,

    /**
     * Milibar 
     */
    MBAR,

    /**
     * Percentage
     */
    PERCENTAGE,

    /**
     * Degree in celsius
     */
    DEGREE_CELSIUS,

    /**
     * Kilometers per hour
     */
    KM_H,

    /**
     * Degree
     */
    DEGREE,

    /**
     * Millimeter
     */
    MM,

    /**
     * Watt per square meter
     */
    W_M2,

    /**
     * Solar radiation
     */
    UV,

    /**
     * Number of vehicles per hour
     */
    TMH;

    /**
     * Returns the string represention for a given unit
     * @param unit the unit
     * @return the string represention for a given unit
     */
    public static String getUnitString(Unit unit) {
        switch (unit) {
            case UG_M3:
                return "μg/m3";
            case MG_M3:
                return "mg/m3";
            case DB:
                return "dB(A)";
            case MBAR:
                return "mbar";
            case PERCENTAGE:
                return "%";
            case DEGREE_CELSIUS:
                return "ºC";
            case KM_H:
                return "km/h";
            case DEGREE:
                return "º";
            case MM:
                return "mm";
            case W_M2:
                return "W/m2";
            case UV:
                return "UV indice";
            case TMH:
                return "Tráfego Médio Horário por via:veículos";
            default:
                return null;
        }
    }

    /**
     * Returns the Unit based on a given String
     * 
     * @param unit The unit
     * @return the Unit based on a given String
     */
    public static Unit getUnitFromString(String unit) {
        switch (unit) {
            case "μg/m3":
                return Unit.UG_M3;
            case "mg/m3":
                return MG_M3;
            case "dB(A)":
                return DB;
            case "mbar":
                return MBAR;
            case "%":
                return PERCENTAGE;
            case "ºC":
                return DEGREE_CELSIUS;
            case "km/h":
                return KM_H;
            case "º":
                return DEGREE;
            case "mm":
                return MM;
            case "W/m2":
                return W_M2;
            case "UV indice":
                return UV;
            case "Tráfego Médio Horário por via:veículos":
                return TMH;
            default:
                return null;
        }
    }
}
