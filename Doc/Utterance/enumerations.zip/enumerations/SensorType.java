package edu.ma02.core.enumerations;

/**
 * <h2>
 * Escola Superior de Tecnologia e Gestão (ESTG)<br>
 * Politécnico do Porto (PP)<br>
 * Licenciatura em Engenharia Informática (LEI)<br>
 * Licenciatura em Segurança Informática em Redes de Computadores (LSIRC)<br>
 * Paradigmas de Programação (PP)<br>
 * 2020 / 2021<br>
 * </h2>
 * <p>
 * Enumeration representing the Sensor type based on {@link Parameter parameter}
 * </p>
 *
 */
public enum SensorType {

    /**
     * Air type
     */
    AIR(new Parameter[]{Parameter.NO2, Parameter.O3, Parameter.PM2_5, Parameter.PM10, Parameter.SO2, Parameter.C6H6, Parameter.CO}),

    /**
     * Noise type
     */
    NOISE(new Parameter[]{Parameter.LAEQ}),

    /**
     * Weather type
     */
    WEATHER(new Parameter[]{Parameter.PA, Parameter.HM, Parameter.TEMP, Parameter.VI, Parameter.VD, Parameter.PC, Parameter.RG, Parameter.RU})
   ;

    private final Parameter[] parameters;

    private SensorType(Parameter[] parameters) {
        this.parameters = parameters;
    }
    
    /**
     * Returns the collection of parameters for a given {@link SensorType SensorType}
     * 
     * @return the collection of parameters for a given {@link SensorType SensorType}
     */
    public Parameter[] getParameters(){
        return this.parameters;
    }
}
